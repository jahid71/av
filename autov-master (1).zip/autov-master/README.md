# Auto Visitor Blog (Custom Refferer)
<br>
<img src="https://i.screenshot.net/l049dtj">
<br><br>
<img src="https://i.screenshot.net/pjmvyc2">
<br><br>
<img src="https://i.screenshot.net/4w3evud">
<br>

<pre>
$ apt update && apt upgrade
$ pkg install php
$ pkg install git
$ git clone https://github.com/underxploit/Autov
$ cd Autov
$ php auto.php
</pre>
